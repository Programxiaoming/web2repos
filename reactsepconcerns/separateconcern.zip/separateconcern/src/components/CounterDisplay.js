import React from 'react';

export function CounterDisplay(props) {
    return <p>{props.count}</p>;
}
