
export function toggle(color) {
    return color === "blue" ? "red" : color === "red" ? "green" : "blue";
}
