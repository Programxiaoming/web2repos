import React from 'react';

export function DisplayMessage(props) {
    return <h1 style={{ color: props.color }}>Hello React World!</h1>;
}
